import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';

const useClientRouter = () => {
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  return isClient ? useRouter() : null;
};

export default useClientRouter;
