import Link from 'next/link';

export default function ProductCard({ product }) {
  return (
    <div className="border rounded-lg p-4">
      <img src={product.image} alt={product.title} className="w-full h-48 object-cover mb-2 rounded" />
      <h2 className="text-lg font-semibold">{product.title}</h2>
      <p className="mt-2">${product.price}</p>
      <Link href={`/products/${product.id}`}>
        <span className="text-blue-500 hover:underline mt-2 block">View Details</span>
      </Link>
    </div>
  );
}
