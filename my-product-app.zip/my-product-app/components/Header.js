import Link from 'next/link';

export default function Header() {
  return (
    <header className="bg-gray-800 text-white p-4">
      <nav className="container mx-auto flex justify-between">
        <Link href="/">
          <span className="text-2xl font-bold">My Product App</span>
        </Link>
        <div>
          <Link href="/">
            <span className="mr-4">Home</span>
          </Link>
          <Link href="/products">
            <span>Products</span>
          </Link>
        </div>
      </nav>
    </header>
  );
}
