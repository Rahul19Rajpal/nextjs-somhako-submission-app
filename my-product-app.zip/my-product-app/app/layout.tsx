import { ReactNode } from 'react';
import '../styles/globals.css';
import DarkModeToggle from '../components/DarkModeToggle';

interface LayoutProps {
  children: ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  return (
    <html lang="en">
      <body>
        <header className="bg-gray-800 text-white p-4">
          <nav className="container mx-auto flex justify-between">
            <a href="/" className="text-2xl font-bold">My Product App</a>
            <div>
              <a href="/" className="mr-4">Home</a>
              <a href="/products" className="mr-4">Products</a>
              <DarkModeToggle />
            </div>
          </nav>
        </header>
        <main className="container mx-auto p-4">
          {children}
        </main>
        <footer className="bg-gray-800 text-white p-4 text-center">
          © 2024 My Product App
        </footer>
      </body>
    </html>
  );
}
