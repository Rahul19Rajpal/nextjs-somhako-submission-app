'use client';
import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';

interface Product {
  id: number;
  title: string;
  price: number;
  description: string;
  category: string;
  image: string;
  rating: {
    rate: number;
    count: number;
  };
}

const fetchProduct = async (id: string): Promise<Product> => {
  const res = await fetch(`https://fakestoreapi.com/products/${id}`);
  if (!res.ok) {
    throw new Error('Failed to fetch product');
  }
  return res.json();
};

const ProductDetailPage = () => {
  const params = useParams();
  const { id } = params;
  const [product, setProduct] = useState<Product | null>(null);

  useEffect(() => {
    if (id) {
      const getProduct = async () => {
        try {
          const fetchedProduct = await fetchProduct(id as string);
          setProduct(fetchedProduct);
        } catch (error) {
          console.error('Error fetching product:', error);
        }
      };

      getProduct();
    }
  }, [id]);

  if (!product) {
    return <div>Loading...</div>;
  }

  return (
    <div className="max-w-3xl mx-auto p-6 bg-white rounded-lg shadow-lg">
      <h1 className="text-3xl font-bold mb-4">{product.title}</h1>
      <img src={product.image} alt={product.title} className="w-full h-96 object-cover mb-4 rounded-lg" />
      <p className="text-gray-700 leading-relaxed">{product.description}</p>
      <p className="mt-4 text-lg font-semibold">Price: ${product.price}</p>
      <p className="mt-2 text-gray-600">Category: {product.category}</p>
      <p className="mt-2 text-gray-600">Rating: {product.rating.rate} ({product.rating.count} reviews)</p>
      
        <a href="/products" className="block mt-8 bg-blue-500 text-white py-2 px-4 rounded-md hover:bg-blue-600 transition duration-300 ease-in-out focus:outline-none">
          Back to Products
        </a>
      
    </div>
  );
};

export default ProductDetailPage;
